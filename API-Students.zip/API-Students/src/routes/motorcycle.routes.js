import { Router } from 'express'
import { getAll, insertOne, getOne } from '../controllers/motorcycle.controller.js'

const motorcycles = Router()

motorcycles.get('/getAllM', getAll)
motorcycles.post('/insertOneM', insertOne)
motorcycles.get('/getOnem/:id' , getOne)

motorcycles.get('/sqrtm/:num', (req, res) => {
    const { num } = req.params
    const sqrt = Math.sqrt(num)
    res.json({"result": sqrt})
})

export default motorcycles