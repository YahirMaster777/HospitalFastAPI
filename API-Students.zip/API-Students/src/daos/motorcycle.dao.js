import Motorcycle from "../models/Motorcycle.js";

const motoDao = {};

//Devuelve todos los estudiantes que esten en la collecion
motoDao.getAll = async () => {
  return await Motorcycle.find();
};

motoDao.insertOne = async motorcycle => {
    return await Motorcycle.create(motorcycle)
}

motoDao.getOne = async id => {
    return await Motorcycle.findOne({moto_id: id})
}

export default motoDao;