import motoDao from "../daos/motorcycle.dao.js";

export const getAll = async (req, res) => {
  motoDao
    .getAll()
    .then((motorcycles) => {
      res.json(motorcycles);
    })
    .catch((error) => {
      res.json({ message: error });
    });
};

export const insertOne = (req, res) => {
  motoDao
    .insertOne(req.body)
    .then((motorcycle) => {
      res.json(motorcycle);
    })
    .catch((error) => res.json({ message: error }));
};

export const getOne = (req, res) => {
    motoDao
        .getOne(req.params.id)
        .then(motorcycle => {
            motorcycle != null ? res.json(motorcycle) : res.json({message: "Motocicleta no encontrado"})
            res.json(motorcycle)
        })
    .catch(error => console.log(error))
}
