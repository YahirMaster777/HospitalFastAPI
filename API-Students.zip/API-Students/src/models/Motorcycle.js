import { Schema, model } from "mongoose";

//Definiendo el schema
const MotoSchema = new Schema(
  {
    moto_id: {
      type: Number,
      required: true,
      unique: true,
    },
    brand: String,
    model: String,
    cc: Number,
    year:Date,
    vin:String
  },
  {
    versionKey: false,
    timestamps: true,
  }
);

//Exportando el modelo
export default model("motorcycle", MotoSchema);
