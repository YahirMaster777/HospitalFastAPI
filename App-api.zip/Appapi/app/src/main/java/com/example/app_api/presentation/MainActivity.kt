/* While this template provides a good starting point for using Wear Compose, you can always
 * take a look at https://github.com/android/wear-os-samples/tree/main/ComposeStarter and
 * https://github.com/android/wear-os-samples/tree/main/ComposeAdvanced to find the most up to date
 * changes to the libraries and their usages.
 */

package com.example.app_api.presentation

import android.content.Context
import android.os.Bundle
import android.telecom.Call
import android.widget.Button
import android.widget.Space
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Devices
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.material.Button
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.Text
import androidx.wear.compose.material.TimeText
import com.example.app_api.R
import com.example.app_api.presentation.theme.AppapiTheme
import com.google.android.gms.common.api.Response
import javax.security.auth.callback.Callback

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()

        super.onCreate(savedInstanceState)

        setTheme(android.R.style.Theme_DeviceDefault)

        setContent {
            WearApp("Android")
        }
    }
}

@Composable
fun WearApp(greetingName: String) {
    AppapiTheme {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colors.background),
            contentAlignment = Alignment.Center
        ) {
            TimeText()
            Greeting(greetingName = greetingName)
        }
    }
}

@Composable
fun Greeting(greetingName: String) {
    var name by remember { mutableStateOf<String?>(null) }
    var studentId by remember { mutableStateOf(TextFieldValue("")) }

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        TextField(
            value = studentId,
            onValueChange = { studentId = it },
            placeholder = {
                Text(
                    text = "Id",
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            },
            textStyle = TextStyle(
                fontSize = 16.sp,
                textAlign = TextAlign.Center
            ),
            modifier = Modifier
                .width(100.dp)
                .height(50.dp)
        )
        Spacer(modifier = Modifier.height(5.dp))
        Button(onClick = {
            val studentIdInt = studentId.text.toIntOrNull()
            if (studentIdInt != null) {
                fetchStudent(context, studentIdInt) { result ->
                    name = result
                }
            } else {
                name = "Invalid ID"
            }
        }) {
            Text("Leer")
        }
        Spacer(modifier = Modifier.height(5.dp))
        name?.let {
            Text(
                text = it,
                style = TextStyle(fontSize = 20.sp, textAlign = TextAlign.Center),
                color = Color.Blue
            )
        }
    }
}

fun fetchStudent(context: Context, studentId: Int, callback: (String) -> Unit) {
    val apiService = RetrofitClient.instance
    val call = apiService.getStudent() // Assuming getStudent takes an ID

    call.enqueue(object : Callback<StudentResponse> {
        override fun onResponse(call: Call<StudentResponse>, response: Response<StudentResponse>) {
            if (response.isSuccessful) {
                val name = response.body()?.name
                callback(name ?: "No name found")
            } else {
                callback("Error fetching student")
            }
        }

        override fun onFailure(call: Call<StudentResponse>, t: Throwable) {
            callback("Network error: ${t.message}")
        }
    })
}



@Preview(device = Devices.WEAR_OS_SMALL_ROUND, showSystemUi = true)
@Composable
fun DefaultPreview() {
    WearApp("Preview Android")
}