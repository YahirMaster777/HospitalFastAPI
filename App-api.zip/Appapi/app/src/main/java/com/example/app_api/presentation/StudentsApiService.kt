package com.example.app_api.presentation

import retrofit2.Call
import retrofit2.http.GET

interface StudentsApiService {
    @GET("getOne/1")
    fun getStudent():Call<StudentResponse>
}