package com.example.app_api.presentation

import com.google.gson.annotations.SerializedName

data class StudentResponse(
    @SerializedName("_id")
    val id: String,  // Renamed to match Kotlin naming conventions

    @SerializedName("student_id")  // Corrected to match typical JSON field naming conventions
    val studentId: Int,  // Renamed to match Kotlin naming conventions

    @SerializedName("name")
    val name: String,

    @SerializedName("lastname")
    val lastname: String,

    @SerializedName("grade")
    val grade: Int,

    @SerializedName("group")
    val group: String,

    @SerializedName("career")
    val career: String,

    @SerializedName("average")
    val average: String
)
