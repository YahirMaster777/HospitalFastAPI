package com.example.geolocalizacion.presentation

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.geolocalizacion.R
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : ComponentActivity() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var textView: TextView

    companion object {
        private const val API_KEY = "4cca2aa3b533bb7f69d044c6054dd006"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textView = findViewById(R.id.textView)

        // Inicializar FusedLocationProviderClient
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Verificar permisos de ubicación y obtener la ubicación
        checkLocationPermissionAndGetLocation()
    }

    private fun checkLocationPermissionAndGetLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            getLastKnownLocation()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            getLastKnownLocation()
        } else {
            textView.text = "Permisos de ubicación denegados"
        }
    }

    private fun getLastKnownLocation() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        fusedLocationClient.lastLocation
            .addOnSuccessListener { location: Location? ->
                if (location != null) {
                    fetchWeatherData(location.latitude, location.longitude)
                } else {
                    requestNewLocationData()
                }
            }
            .addOnFailureListener { e ->
                textView.text = "Error al obtener la ubicación: ${e.message}"
            }
    }

    private fun requestNewLocationData() {
        val locationRequest = LocationRequest.create().apply {
            interval = 5000 // Intervalo de 5 segundos
            fastestInterval = 3000 // Intervalo más rápido de 3 segundos
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        }

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        fusedLocationClient.requestLocationUpdates(locationRequest, object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                val location = locationResult.lastLocation
                if (location != null) {
                    fetchWeatherData(location.latitude, location.longitude)
                    // Detener las actualizaciones de ubicación después de obtener una ubicación válida
                    fusedLocationClient.removeLocationUpdates(this)
                } else {
                    textView.text = "No se pudo obtener la ubicación"
                }
            }
        }, null)
    }

    private fun fetchWeatherData(lat: Double, lon: Double) {
        val call = RetrofitClient.instance.getCurrentWeatherData(lat, lon, API_KEY)
        call.enqueue(object : Callback<GeoResponse> {
            override fun onResponse(call: Call<GeoResponse>, response: Response<GeoResponse>) {
                if (response.isSuccessful) {
                    val weather = response.body()
                    weather?.let {
                        val tempInCelsius = it.main.temp - 273.15
                        val weatherInfo = """
                            Latitud: ${it.coord.lat}
                            Longitud: ${it.coord.lon}
                            Ciudad: ${it.name}
                            Temperatura: ${"%.2f".format(tempInCelsius)}°C
                            Humedad: ${it.main.humidity}%
                            Clima: ${it.weather[0].description?.capitalize() ?: "Sin descripción"}
                        """.trimIndent()
                        textView.text = weatherInfo
                    }
                } else {
                    textView.text = "Error al obtener los datos del clima"
                }
            }

            override fun onFailure(call: Call<GeoResponse>, t: Throwable) {
                textView.text = "Error de red: ${t.message}"
            }
        })
    }
}
