package com.example.geolocalizacion.presentation

import com.google.gson.annotations.SerializedName

data class GeoResponse(
    @SerializedName("coord")
    val coord: Coord,

    @SerializedName("main")
    val main: Main,

    @SerializedName("name")
    val name: String?,

    @SerializedName("weather")
    val weather: List<Weather>,

    @SerializedName("pop")
    val pop: Double // Probabilidad de precipitación (lluvia) en porcentaje
)

data class Coord(
    @SerializedName("lat")
    val lat: Double,

    @SerializedName("lon")
    val lon: Double
)

data class Main(
    @SerializedName("temp")
    val temp: Double,

    @SerializedName("pressure")
    val pressure: Int, // Presión atmosférica en hPa

    @SerializedName("humidity")
    val humidity: Int // Humedad en porcentaje
)

data class Weather(
    @SerializedName("description")
    val description: String?
)
