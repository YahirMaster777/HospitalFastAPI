package com.example.geolocalizacion.presentation

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface GeoApiService {
    @GET("weather")
    fun getCurrentWeatherData(
        @Query("lat") lat: Double,
        @Query("lon") lon: Double,
        @Query("appid") apiKey: String,
        @Query("temp") units: String = "metric",  // Para obtener la temperatura en grados Celsius
        @Query("lang") lang: String = "es"         // Para recibir la respuesta en español
    ): Call<GeoResponse>
}
