package com.example.geolocalizacion.presentation
import com.google.android.gms.awareness.snapshot.LocationResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query


interface GeoApiService {
    @GET("weather")
    fun getCurrentWeatherData(
        @Query("lat") lat: Double,
        @Query("lon") lon: Double,
        @Query("appid") apiKey: String
    ): Call<GeoResponse>
}
