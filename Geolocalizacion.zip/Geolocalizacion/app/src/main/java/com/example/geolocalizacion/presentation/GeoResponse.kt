package com.example.geolocalizacion.presentation

import com.google.gson.annotations.SerializedName

data class GeoResponse(
    @SerializedName("coord")
    val coord: Coord,

    @SerializedName("weather")
    val weather: List<Weather>,


)

data class Coord(
    @SerializedName("lat")
    val lat: Double,

    @SerializedName("lon")
    val lon: Double
)

data class Weather(
    @SerializedName("description")
    val description: String?
)