/* While this template provides a good starting point for using Wear Compose, you can always
 * take a look at https://github.com/android/wear-os-samples/tree/main/ComposeStarter and
 * https://github.com/android/wear-os-samples/tree/main/ComposeAdvanced to find the most up to date
 * changes to the libraries and their usages.
 */

package com.example.studentsconection.presentation

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TextFieldDefaults.textFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Devices
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.material.Button
import androidx.wear.compose.material.ButtonDefaults
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.Text
import androidx.wear.compose.material.TimeText
import com.example.studentsconection.presentation.theme.StudentsConectionTheme
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()

        super.onCreate(savedInstanceState)

        setTheme(android.R.style.Theme_DeviceDefault)

        setContent {
            WearApp("Android")
        }
    }
}

@Composable
fun WearApp(greetingName: String) {
    StudentsConectionTheme {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colors.background),
            contentAlignment = Alignment.Center
        ) {
            TimeText()
            Greeting(greetingName = greetingName)
        }
    }
}@Composable
fun Greeting(greetingName: String) {
    var name by remember { mutableStateOf("") }
    var studentId by remember { mutableStateOf(TextFieldValue("")) }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TextField(
            value = studentId,
            onValueChange = { studentId = it },
            placeholder = {
                Text(
                    text = "Ingresa el ID",
                    style = TextStyle(fontSize = 6.sp),
                    color = Color.Gray
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 1.dp)
                .height(40.dp),
            textStyle = TextStyle(fontSize = 8.sp)
        )

        Button(
            onClick = {
                val id = studentId.text.toIntOrNull()
                if (id != null) {
                    fetchStudent(context, id) { firstName, lastName ->
                        name = if (firstName.isNullOrEmpty() && lastName.isNullOrEmpty()) {
                            "Estudiante no encontrado"
                        } else {
                            val displayedName = firstName ?: "No disponible"
                            "Nombre: $displayedName\nApellido: $lastName"
                        }
                    }
                } else {
                    name = "ID inválido"
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 2.dp)
                .height(18.dp)
        ) {
            Text("Leer", fontSize = 6.sp)
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = name,  // Display the name and lastname in separate lines
            style = TextStyle(fontSize = 12.sp),
            color = Color.White
        )
    }
}

fun fetchStudent(context: Context, studentId: Int, callback: (String?, String?) -> Unit) {
    val apiService = RetrofitClient.instance
    val call = apiService.getStudent(studentId)
    call.enqueue(object : Callback<StudentResponse> {
        override fun onResponse(call: Call<StudentResponse>, response: Response<StudentResponse>) {
            if (response.isSuccessful) {
                val student = response.body()
                callback(student?.name, student?.lastname)
            } else {
                callback(null, null)  // Indicate that the student was not found
            }
        }

        override fun onFailure(call: Call<StudentResponse>, t: Throwable) {
            callback(null, null)  // Indicate a failure in fetching the student
        }
    })
}



@Preview(device = Devices.WEAR_OS_SMALL_ROUND, showSystemUi = true)
@Composable
fun DefaultPreview() {
    WearApp("Preview Android")
}