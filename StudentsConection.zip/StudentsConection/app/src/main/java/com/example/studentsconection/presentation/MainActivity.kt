/* While this template provides a good starting point for using Wear Compose, you can always
 * take a look at https://github.com/android/wear-os-samples/tree/main/ComposeStarter and
 * https://github.com/android/wear-os-samples/tree/main/ComposeAdvanced to find the most up to date
 * changes to the libraries and their usages.
 */

package com.example.studentsconection.presentation

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TextFieldDefaults.textFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Devices
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.material.Button
import androidx.wear.compose.material.ButtonDefaults
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.Text
import androidx.wear.compose.material.TimeText
import com.example.studentsconection.presentation.theme.StudentsConectionTheme
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()

        super.onCreate(savedInstanceState)

        setTheme(android.R.style.Theme_DeviceDefault)

        setContent {
            WearApp("Android")
        }
    }
}

@Composable
fun WearApp(greetingName: String) {
    StudentsConectionTheme {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colors.background),
            contentAlignment = Alignment.Center
        ) {
            TimeText()
            Greeting(greetingName = greetingName)
        }
    }
}
@Composable
fun Greeting(greetingName: String) {
    var name by remember { mutableStateOf<String?>(value = null) }
    var studentId by remember { mutableStateOf(TextFieldValue("")) }
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp), // Padding general
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Campo de entrada para el ID
        TextField(
            value = studentId,
            onValueChange = { studentId = it },
            placeholder = {
                Text(
                    text = "Ingresa el ID",
                    style = TextStyle(fontSize = 6.sp), // Tamaño de texto del placeholder
                    color = Color.Gray
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 1.dp) // Padding inferior
                .height(40.dp), // Tamaño del TextField
            textStyle = TextStyle(fontSize = 8.sp) // Tamaño del texto ingresado
        )

        // Botón "Leer"
        Button(
            onClick = {
                // Validar si el ID es un número
                val id = studentId.text.toIntOrNull()
                if (id != null) {
                    fetchStudent(context , id) { result ->
                        name = result
                    }
                } else {
                    name = "ID inválido"
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 2.dp) // Margen superior
                .height(18.dp) // Tamaño del botón
        ) {
            Text("Leer", fontSize = 6.sp)
        }

        // Resultado (nombre)
        Spacer(modifier = Modifier.height(0.dp))
        name?.let {
            Text(
                text = it,
                style = TextStyle(fontSize = 12.sp),
                color = Color.White
            )
        }
    }
}


fun fetchStudent(context: Context, studentId: Int, callback: (String?) -> Unit) {
    val apiService = RetrofitClient.instance
    val call = apiService.getStudent(studentId)
    call.enqueue(object : Callback<StudentResponse> {
        override fun onResponse(call: Call<StudentResponse>, response: Response<StudentResponse>) {
            if (response.isSuccessful) {
                //crear una nueva variable student
                //para guardar la respuesta/json
                val student = response.body()
                student?.let {
                    callback("Nombre: ${it.name} \nGrado y grupo: ${it.grade} ${it.group}")
                } ?: run {
                    callback("Error al procesar los datos del estudiante")
                }
            } else {
                callback("Error al descargar estudiante: ${response.errorBody()?.string()}")
            }
        }

        override fun onFailure(call: Call<StudentResponse>, t: Throwable) {
            callback("Error de red: ${t.message}")
        }
    })
}


@Preview(device = Devices.WEAR_OS_SMALL_ROUND, showSystemUi = true)
@Composable
fun DefaultPreview() {
    WearApp("Preview Android")
}