package com.example.studentsconection.presentation

import retrofit2.Call
import retrofit2.http.GET

import retrofit2.http.Path

interface StudentsApiService {
    @GET("getOne/{id}")
    fun getStudent(@Path("id") studentId: Int): Call<StudentResponse>
}
